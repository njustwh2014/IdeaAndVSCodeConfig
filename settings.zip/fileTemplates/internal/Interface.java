#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @program:${PROJECT_NAME}
* 
* @description:${description}
*
* @author: Huan Wang(https://github.com/njustwh2014)
*
* @create:${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
*
**/
public interface ${NAME} {
}
